// Crear el mapa centrado en UK
const map = L.map('map').setView([54.5, -3.5], 6);

// Capas base disponibles
const baseLayers = {
  osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 18
  }),
  street: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, DeLorme, NAVTEQ',
    maxZoom: 20
  }),
  heat: L.tileLayer('https://stamen-tiles.a.ssl.fastly.net/toner-lite/{z}/{x}/{y}.png', {
    attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://osm.org/copyright">OpenStreetMap</a>',
    maxZoom: 20
  }),
  minimalist: L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 19
  })
};

// Agregar la capa base inicial (OSM)
baseLayers.osm.addTo(map);

// Función para cambiar la capa base
function changeBaseLayer(layerName) {
  if (baseLayers[layerName]) {
    map.eachLayer(layer => {
      if (layer instanceof L.TileLayer && !layer.getAttribution().includes('GeoJSON')) {
        map.removeLayer(layer);
      }
    });
    baseLayers[layerName].addTo(map);
  }
}

// Cargar y agregar las zonas de calor
let dataLayer; // Declarar para referencia global

fetch('ltla2024.geojson')
  .then(response => response.json())
  .then(data => {
    dataLayer = L.geoJson(data, {
      style: feature => {
        const intensity = feature.properties.intensity || Math.random();
        return {
          fillColor: getColor(intensity),
          weight: 2,
          opacity: 1,
          color: 'white',
          dashArray: '3',
          fillOpacity: 0.7
        };
      },
      onEachFeature: (feature, layer) => {
        layer.bindPopup(
          `<b>${feature.properties.areanm}</b><br>Intensidad: ${feature.properties.intensity || 'Sin datos'}`
        );
      }
    }).addTo(map);
  })
  .catch(error => console.error('Error cargando el GeoJSON:', error));

// Función para calcular el color según intensidad
function getColor(intensity) {
  return intensity > 0.8
    ? '#800026'
    : intensity > 0.6
    ? '#BD0026'
    : intensity > 0.4
    ? '#E31A1C'
    : intensity > 0.2
    ? '#FC4E2A'
    : '#FFEDA0';
}

// Cambiar capa base según selección del usuario
document.getElementById('mapSelector').addEventListener('change', event => {
  changeBaseLayer(event.target.value);
});
